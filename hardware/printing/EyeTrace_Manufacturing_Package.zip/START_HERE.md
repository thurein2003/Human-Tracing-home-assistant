# Eye Trace manufacturing package

Both configurations are engineering candidates. The original geometry is preserved.
Print fit gauges and record physical measurements before committing to a full assembly.

## 01 Legacy five-arm with 21 × 14 mm camera pitch

This is the 13-part K2 ABS build candidate. It retains five-arm horn pockets on both
drive carriers. Use the K2 3MF for the archived plate orientation and support settings.
The full-bed STL contains the same 13 placed meshes. Individual_STL contains one
separate file per part, in the editable layout's orientation. Editable_CAD contains
the corrected assembly, motion assembly, print layout and STEP exchanges.

The archived K2 profile uses a 0.4 mm nozzle, 0.20 mm layers, four walls, 255 °C nozzle,
100 °C first-layer bed, and 35% gyroid by default. The base, yoke and tilt
cradle use slim tree supports. The ring, horn covers, journal sleeve, PCB spacers
and camera plate use 100% infill. The 3MF carries the per-object brim settings.
The archived full bed has a 217.097 × 218.000 × 67.175 mm model envelope.

## 02 Fit tests

- Camera_21x14 contains the dedicated camera hole-pattern coupon. Check the actual
  mounting holes, rear components and screw clearance before a full print.
- Pan_Ring_and_Tilt_Journal contains the 20-piece clearance bed and the individual
  gauge files. The very same T1 journal mesh is used for all five tilt bore variants.
  Pan diametral gaps run from 0.10 to 0.60 mm. The 5.00 mm tilt journal mates
  to test bores of 5.05, 5.10, 5.15, 5.20 and 5.30 mm.
- White_Four_Arm_Horn_R15 contains the R15 negative pocket master. A later repair record
  reports that the real horn fit this separate gauge. The installed screw engagement
  and loaded fit remain unverified. A production mold for the horn remains missing.
- Historical_Mixed_Gauges contains the earlier seven-piece diagnostic bed. Use
  Camera_21x14 as the camera pitch reference.

## 03 R15 four-arm engineering hold

The R15 FreeCAD assembly and fixed-layout 3MF are preserved here as engineering
references. This design uses four-arm pockets derived from the white-horn gauge.
The fixed plate passed geometry and placement checks. Toolpath and assembly approval
remain open. Keep R15 and legacy parts in their original configurations.

Camera rear-component and fastener clearance, printed pan and tilt clearances, and
installed R15 horn engagement require physical verification. Raspberry Pi runtime
recovery remains pending.

SHA256SUMS verifies the contents. SOURCE_FILES.csv maps each CAD and print file to
its path in the repository.
